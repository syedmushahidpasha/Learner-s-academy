package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.dao.SubjectDao;
import com.entity.Subject;

public class SubjectService {

	SubjectDao pd = new SubjectDao();
  
	public String storeSubject(String name) {
		if (name == "")
			return "Cannot add empty subject name";
		else if (!pd.findSubjectByName(name).isEmpty())
			return "Subject already exists";
		else 
			return pd.storeSubject(name);
	}
	
	public String deleteSubject (int id) {
		return pd.deleteSubject(id);
	}
	
	public String findSubjectById (int id) {
		Subject pp = pd.findSubjectById(id);
		if (pp == null) 
			return "Subject not found";
		else 
			return pp.getName();
	}
	
	public Subject findSubjectByName (String name) {
		List<Subject> pp = pd.findSubjectByName(name);
		return pp.get(0);
	}
	
	public List<String> findSubjectAllSubject() {
		List<String> output = new ArrayList<String>();
		List<Subject> subjects = pd.findSubjectAllSubject();
		Iterator<Subject> li = subjects.iterator();
		while (li.hasNext()) {
			Subject subject = li.next(); 
			output.add(subject.getName());
		}
		return output;
	}
	
}
