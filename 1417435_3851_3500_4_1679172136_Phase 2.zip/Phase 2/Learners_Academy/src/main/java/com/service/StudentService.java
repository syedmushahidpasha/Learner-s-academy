package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.dao.AcademyClassDao;
import com.dao.StudentDao;
import com.entity.AcademyClass;
import com.entity.Student;

public class StudentService {

	StudentDao pd = new StudentDao();
	AcademyClassDao ad = new AcademyClassDao();
  
	public String storeStudent(String name, String className) {
		if (name == "")
			return "Cannot add empty student name";
		else if (!pd.findStudentByName(name).isEmpty())
			return "Student already exists";
		else {
			List<AcademyClass> ac = ad.findAcademyClassByName (className);
			if (ac.isEmpty())
				return "Class not found";
			return pd.storeStudent(name, ac.get(0).getId());
		}
	}
	
	public String deleteStudent (int id) {
		return pd.deleteStudent(id);
	}
	
	public String findStudentById (int id) {
		Student pp = pd.findStudentById(id);
		if (pp == null) 
			return "Student not found";
		else 
			return pp.getName();
	}
	
	public Student findStudentByName (String name) {
		List<Student> pp = pd.findStudentByName(name);
		return pp.get(0);
	}
	
	public List<String> findStudentAllStudent() {
		List<String> output = new ArrayList<String>();
		List<Student> students = pd.findStudentAllStudent();
		Iterator<Student> li = students.iterator();
		while (li.hasNext()) {
			Student student = li.next(); 
			output.add(student.getName());
			int cid = student.getCid();
			AcademyClass ac = ad.findAcademyClassById (cid);
			output.add(ac.getName());
		}
		return output;
	}
	
}
