package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.dao.TeacherDao;
import com.entity.Teacher;

public class TeacherService {

	TeacherDao pd = new TeacherDao();
  
	public String storeTeacher(String name) {
		if (name == "")
			return "Cannot add empty teacher name";
		else if (!pd.findTeacherByName(name).isEmpty())
			return "Teacher already exists";
		else 
			return pd.storeTeacher(name);
	}
	
	public String deleteTeacher (int id) {
		return pd.deleteTeacher(id);
	}
	
	public String findTeacherById (int id) {
		Teacher pp = pd.findTeacherById(id);
		if (pp == null) 
			return "Teacher not found";
		else 
			return pp.getName();
	}
	
	public Teacher findTeacherByName (String name) {
		List<Teacher> pp = pd.findTeacherByName(name);
		return pp.get(0);
	}
	
	public List<String> findTeacherAllTeacher() {
		List<String> output = new ArrayList<String>();
		List<Teacher> teachers = pd.findTeacherAllTeacher();
		Iterator<Teacher> li = teachers.iterator();
		while (li.hasNext()) {
			Teacher teacher = li.next(); 
			output.add(teacher.getName());
		}
		return output;
	}
	
}
