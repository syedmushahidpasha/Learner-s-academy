package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.dao.AcademyClassDao;
import com.dao.AssignmentDao;
import com.dao.TeacherDao;
import com.dao.SubjectDao;
import com.entity.Teacher;
import com.entity.Subject;
import com.entity.AcademyClass;
import com.entity.Assignment;

public class AssignmentService {

	AssignmentDao pd = new AssignmentDao();
	AcademyClassDao ad = new AcademyClassDao();
	TeacherDao td = new TeacherDao();
	SubjectDao sd = new SubjectDao();
  
	public String storeAssignment(String teacherName, String subjectName, String className) {
		try {
			if (teacherName == "")
				return "Cannot add empty teacher name";
			if (subjectName == "")
				return "Cannot add empty subject name";
			if (className == "")
				return "Cannot add empty class name";
		
			List<Teacher> td1 = td.findTeacherByName(teacherName);
			if (td1.isEmpty())
				return "Teacher not found";
			List<Subject> sd1 = sd.findSubjectByName(subjectName);
			if (sd1.isEmpty())
				return "Subject not found";
			List<AcademyClass> ad1 = ad.findAcademyClassByName(className);
			if (ad1.isEmpty())
				return "Class not found";
			if (!pd.findAssignmentByData(td1.get(0).getId(), sd1.get(0).getId(), ad1.get(0).getId()).isEmpty())
				return "Assignment already exists";
			return pd.storeAssignment(td1.get(0).getId(), sd1.get(0).getId(), ad1.get(0).getId());
		} 
		catch(Exception e) {		
			return e.getMessage();		
		}	
	}
	
	public String deleteAssignment (int id) {
		return pd.deleteAssignment(id);
	}
			
	public List<String> findAssignmentAllAssignment() {
		List<String> output = new ArrayList<String>();
		List<Assignment> assignments = pd.findAssignmentAllAssignment();
		Iterator<Assignment> li = assignments.iterator();
		while (li.hasNext()) {
			Assignment assignment = li.next(); 
		
			int cid = assignment.getCid();
			AcademyClass ac = ad.findAcademyClassById (cid);
			output.add(ac.getName());
			
			int sid = assignment.getSid();
			Subject sj = sd.findSubjectById (sid);
			output.add(sj.getName());

			int tid = assignment.getTid();
			Teacher tc = td.findTeacherById (tid);
			output.add(tc.getName());			
		}
		return output;
	}
	
	public List<String> findAllAssignmentsPerClass(String className) {
		List<String> output = new ArrayList<String>();
		List<AcademyClass> ac = ad.findAcademyClassByName (className);
		List<Assignment> assignments = pd.findAssignmentByClass(ac.get(0).getId());
		
		Iterator<Assignment> li = assignments.iterator();
		while (li.hasNext()) {
			Assignment assignment = li.next(); 
			
			int sid = assignment.getSid();
			Subject sj = sd.findSubjectById (sid);
			output.add(sj.getName());

			int tid = assignment.getTid();
			Teacher tc = td.findTeacherById (tid);
			output.add(tc.getName());			
		}
		return output;
	}
	
}
