package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.dao.AcademyClassDao;
import com.entity.AcademyClass;
import com.entity.Student;

public class AcademyClassService {

	AcademyClassDao pd = new AcademyClassDao();
  
	public String storeAcademyClass(String name) {
		if (name == "")
			return "Cannot add empty class name";
		else if (!pd.findAcademyClassByName(name).isEmpty())
			return "Class already exists";
		else 
			return pd.storeAcademyClass(name);
	}
	
	public String deleteAcademyClass (int id) {
		return pd.deleteAcademyClass(id);
	}
	
	public String findAcademyClassById (int id) {
		AcademyClass pp = pd.findAcademyClassById(id);
		if (pp == null) 
			return "Class not found";
		else 
			return pp.getName();
	}
	
	public AcademyClass findAcademyClassByName (String name) {
		List<AcademyClass> pp = pd.findAcademyClassByName(name);
		return pp.get(0);
	}
	
	public List<String> findAcademyClassAllAcademyClass() {
		List<String> output = new ArrayList<String>();
		List<AcademyClass> academyClasses = pd.findAcademyClassAllAcademyClass();
		Iterator<AcademyClass> li = academyClasses.iterator();
		while (li.hasNext()) {
			AcademyClass academyClass = li.next(); 
			output.add(academyClass.getName());
		}
		return output;
	}
	
	public List<String> findAllStudentsPerClass(String className) {
		List<String> output = new ArrayList<String>();
		AcademyClass ac = findAcademyClassByName(className);
		Iterator<Student> li = ac.getListOfStd().iterator();
		
		while (li.hasNext()) {
			Student student = li.next(); 
			output.add(student.getName());
		}
		return output;
	}
}
