package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.AcademyClassService;

/**
 * Servlet implementation class StudentReport
 */

public class StudentReport extends HttpServlet {

	AcademyClassService acs = new AcademyClassService();
	
	public StudentReport() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		RequestDispatcher rd1 = request.getRequestDispatcher("reports.html");
		response.setContentType("text/html");
		
		String cname = request.getParameter("cname");
		List<String> output = acs.findAllStudentsPerClass (cname);
		Iterator<String> li = output.iterator();
		
		pw.println("<table>\n" + 
				"  <tr>\n" + 
				"    <th>Class</th>\n" + 
				"    <th>Student</th>\n" +
				"  </tr>");
		while (li.hasNext()) {
			String student = li.next(); 
			pw.println("<tr><td>" + cname + "</td>");
			pw.println("<td>" + student + "</td></tr>");
		}
		pw.println("</table>");
		
		rd1.include(request, response);
		
	}
}
