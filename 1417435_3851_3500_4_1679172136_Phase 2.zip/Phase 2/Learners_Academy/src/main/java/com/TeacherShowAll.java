package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.Teacher;
import com.service.TeacherService;

/**
 * Servlet implementation class TeacherShowAll
 */

public class TeacherShowAll extends HttpServlet {
	
	TeacherService pd = new TeacherService();
	
	public TeacherShowAll() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		RequestDispatcher rd1 = request.getRequestDispatcher("teachers.html");
		response.setContentType("text/html");
		
		List<String> output = pd.findTeacherAllTeacher();
		Iterator<String> li = output.iterator();
		while (li.hasNext()) {
			String teacher = li.next(); 
			pw.println("<h3>" + teacher + "</h3>");
		}
		
		rd1.include(request, response);
		
	}

}
