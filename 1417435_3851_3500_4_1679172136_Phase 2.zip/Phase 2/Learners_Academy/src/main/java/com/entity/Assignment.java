package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Assignment {
	
	@Id	  
	@GeneratedValue(strategy = GenerationType.IDENTITY)		
	private int id;	
	private int tid;	// FK to Teacher.id
	private int sid;	// FK to Subject.id
	private int cid;	// FK to AcademyClass.id
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	
	@Override
	public String toString() {
		return "Assignment [id=" + id + ", tid=" + tid + ", sid=" + sid + ", cid=" + cid + "]";
	}
	
}
