package com.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class AcademyClass {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)	
  private int id;
  private String name;
  @OneToMany
  @JoinColumn(name = "cid")		// this annotation is use to link fk in student table 
  private List<Student> listOfStd;			// class has more than one student

  public int getId() {
	return id;
  }
  
  public void setId(int id) {
	this.id = id;
  }
  
  public String getName() {
	return name;
  }
  
  public void setName(String name) {
	this.name = name;
  }
	
  public List<Student> getListOfStd() {
	return listOfStd;
  }
	
  public void setListOfStd(List<Student> listOfStd) {
	this.listOfStd = listOfStd;
  }	
  
  @Override
  public String toString() {
	return "AcademyClass [id=" + id + ", name=" + name + "]";
  }
    
}
