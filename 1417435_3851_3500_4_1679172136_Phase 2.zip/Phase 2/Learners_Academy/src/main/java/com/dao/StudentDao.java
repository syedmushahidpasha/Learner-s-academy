package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Student;
import com.resource.DbResource;

public class StudentDao {

	SessionFactory sf;
		
	public StudentDao() {				
		sf = DbResource.getSessionFactory();
	}

	public String storeStudent (String name, int classID) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Student student = new Student();
			student.setName(name);
			student.setCid(classID);
			tran.begin();
				session.save(student);
			tran.commit();
			return "Student stored successfully";
		} 
		catch(Exception e) {		
			return e.getMessage();		
		}	
	}
    
	public String deleteStudent (int id) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Student s = session.get(Student.class, id);
			if (s == null) 
				return "No data found to delete";
			else {
				tran.begin();
					session.delete(s);
				tran.commit();
				return "Student deleted successfully";
			}		
		}
		catch(Exception e) {
			return e.getMessage();	
		}	
	}
  
	public Student findStudentById(int id) {	
		Session session = sf.openSession();		
		Student s = session.get(Student.class, id);		
		return s;		
	}

	public List<Student> findStudentByName (String name) {
		Session session = sf.openSession();
		TypedQuery<Student> tq = session.createQuery("select e from Student e where name = '" + name + "'");
		List<Student> listOfStudent = tq.getResultList();
		return listOfStudent;
	}
	
	public List<Student> findStudentAllStudent() {
		Session session = sf.openSession();
		TypedQuery<Student> tq = session.createQuery("from Student");
		List<Student> listOfStudent = tq.getResultList();
		return listOfStudent;
	}

}
