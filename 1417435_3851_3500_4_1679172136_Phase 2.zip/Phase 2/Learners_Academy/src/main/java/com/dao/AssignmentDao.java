package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Assignment;
import com.resource.DbResource;

public class AssignmentDao {

	SessionFactory sf;
		
	public AssignmentDao() {				
		sf = DbResource.getSessionFactory();
	}

	public String storeAssignment (int tid, int sid, int cid) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Assignment assignment = new Assignment();
			assignment.setTid(tid);
			assignment.setSid(sid);
			assignment.setCid(cid);
			tran.begin();
				session.save(assignment);
			tran.commit();
			return "Assignment stored successfully";
		} 
		catch(Exception e) {		
			return e.getMessage();		
		}	
	}
    
	public String deleteAssignment (int id) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Assignment s = session.get(Assignment.class, id);
			if (s == null) 
				return "No data found to delete";
			else {
				tran.begin();
					session.delete(s);
				tran.commit();
				return "Assignment deleted successfully";
			}		
		}
		catch(Exception e) {
			return e.getMessage();	
		}	
	}
  
	public Assignment findAssignmentById(int id) {	
		Session session = sf.openSession();		
		Assignment s = session.get(Assignment.class, id);		
		return s;		
	}

	public List<Assignment> findAssignmentByData (int tid, int sid, int cid) {
		Session session = sf.openSession();
		TypedQuery<Assignment> tq = session.createQuery
				("select e from Assignment e where tid = '" + tid + "' and sid = '" + sid + "' and cid = '" + cid + "'");
		List<Assignment> listOfAssignment = tq.getResultList();
		return listOfAssignment;
	}
	
	public List<Assignment> findAssignmentByClass (int cid) {
		Session session = sf.openSession();
		TypedQuery<Assignment> tq = session.createQuery
				("select e from Assignment e where cid = '" + cid + "'");
		List<Assignment> listOfAssignment = tq.getResultList();
		return listOfAssignment;
	}
		
	public List<Assignment> findAssignmentAllAssignment() {
		Session session = sf.openSession();
		TypedQuery<Assignment> tq = session.createQuery("from Assignment");
		List<Assignment> listOfAssignment = tq.getResultList();
		return listOfAssignment;
	}

}
