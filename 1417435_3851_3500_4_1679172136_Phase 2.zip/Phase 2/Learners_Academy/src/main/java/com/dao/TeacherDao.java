package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Teacher;
import com.resource.DbResource;

public class TeacherDao {

	SessionFactory sf;
		
	public TeacherDao() {				
		sf = DbResource.getSessionFactory();
	}

	public String storeTeacher (String name) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Teacher teacher = new Teacher();
			teacher.setName(name);
			tran.begin();
				session.save(teacher);
			tran.commit();
			return "Teacher stored successfully";
		} 
		catch(Exception e) {		
			return e.getMessage();		
		}	
	}
    
	public String deleteTeacher (int id) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Teacher s = session.get(Teacher.class, id);
			if (s == null) 
				return "No data found to delete";
			else {
				tran.begin();
					session.delete(s);
				tran.commit();
				return "Teacher deleted successfully";
			}		
		}
		catch(Exception e) {
			return e.getMessage();	
		}	
	}
  
	public Teacher findTeacherById(int id) {	
		Session session = sf.openSession();		
		Teacher s = session.get(Teacher.class, id);		
		return s;		
	}

	public List<Teacher> findTeacherByName (String name) {
		Session session = sf.openSession();
		TypedQuery<Teacher> tq = session.createQuery("select e from Teacher e where name = '" + name + "'");
		List<Teacher> listOfTeacher = tq.getResultList();
		return listOfTeacher;
	}
	
	public List<Teacher> findTeacherAllTeacher() {
		Session session = sf.openSession();
		TypedQuery<Teacher> tq = session.createQuery("from Teacher");
		List<Teacher> listOfTeacher = tq.getResultList();
		return listOfTeacher;
	}

}
