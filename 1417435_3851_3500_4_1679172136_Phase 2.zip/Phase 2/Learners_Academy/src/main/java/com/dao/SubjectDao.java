package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Subject;
import com.resource.DbResource;

public class SubjectDao {

	SessionFactory sf;
		
	public SubjectDao() {				
		sf = DbResource.getSessionFactory();
	}

	public String storeSubject(String name) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Subject subject = new Subject();
			subject.setName(name);
			tran.begin();
				session.save(subject);
			tran.commit();
			return "Subject stored successfully";
		} 
		catch(Exception e) {		
			return e.getMessage();		
		}	
	}
    
	public String deleteSubject(int id) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			Subject s = session.get(Subject.class, id);
			if (s == null) 
				return "No data found to delete";
			else {
				tran.begin();
					session.delete(s);
				tran.commit();
				return "Subject deleted successfully";
			}		
		}
		catch(Exception e) {
			return e.getMessage();	
		}	
	}
  
	public Subject findSubjectById(int id) {	
		Session session = sf.openSession();		
		Subject s = session.get(Subject.class, id);		
		return s;		
	}

	public List<Subject> findSubjectByName (String name) {
		Session session = sf.openSession();
		TypedQuery<Subject> tq = session.createQuery("select e from Subject e where name = '" + name + "'");
		List<Subject> listOfSubject = tq.getResultList();
		return listOfSubject;
	}
	
	public List<Subject> findSubjectAllSubject() {
		Session session = sf.openSession();
		TypedQuery<Subject> tq = session.createQuery("from Subject");
		List<Subject> listOfSubject = tq.getResultList();
		return listOfSubject;
	}

}
