package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.AcademyClass;
import com.resource.DbResource;

public class AcademyClassDao {

	SessionFactory sf;
		
	public AcademyClassDao() {				
		sf = DbResource.getSessionFactory();
	}

	public String storeAcademyClass (String name) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			AcademyClass academyClass = new AcademyClass();
			academyClass.setName(name);
			tran.begin();
				session.save(academyClass);
			tran.commit();
			return "Class stored successfully";
		} 
		catch(Exception e) {		
			return e.getMessage();		
		}	
	}
    
	public String deleteAcademyClass (int id) {
		try {
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			AcademyClass s = session.get(AcademyClass.class, id);
			if (s == null) 
				return "No data found to delete";
			else {
				tran.begin();
					session.delete(s);
				tran.commit();
				return "AcademyClass deleted successfully";
			}		
		}
		catch(Exception e) {
			return e.getMessage();	
		}	
	}
  
	public AcademyClass findAcademyClassById(int id) {	
		Session session = sf.openSession();		
		AcademyClass s = session.get(AcademyClass.class, id);		
		return s;		
	}

	public List<AcademyClass> findAcademyClassByName (String name) {
		Session session = sf.openSession();
		TypedQuery<AcademyClass> tq = session.createQuery("select e from AcademyClass e where name = '" + name + "'");
		List<AcademyClass> listOfAcademyClass = tq.getResultList();
		return listOfAcademyClass;
	}
	
	public List<AcademyClass> findAcademyClassAllAcademyClass() {
		Session session = sf.openSession();
		TypedQuery<AcademyClass> tq = session.createQuery("from AcademyClass");
		List<AcademyClass> listOfAcademyClass = tq.getResultList();
		return listOfAcademyClass;
	}

}
