package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.TeacherService;

/**
 * Servlet implementation class TeacherAdd
 */
public class TeacherAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;
	TeacherService pd = new TeacherService();
       
    public TeacherAdd() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		RequestDispatcher rd1 = request.getRequestDispatcher("teachers.html");
		response.setContentType("text/html");
		String name = request.getParameter("name");
		String output = pd.storeTeacher(name);
		pw.println(output);
		rd1.include(request, response);
	}

}
