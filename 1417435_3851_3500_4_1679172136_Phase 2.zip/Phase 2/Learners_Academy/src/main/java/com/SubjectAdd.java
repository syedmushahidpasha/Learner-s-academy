package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.SubjectService;

/**
 * Servlet implementation class SubjectAdd
 */
public class SubjectAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;
	SubjectService pd = new SubjectService();
       
    public SubjectAdd() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		RequestDispatcher rd1 = request.getRequestDispatcher("subjects.html");
		response.setContentType("text/html");
		String name = request.getParameter("subname");
		String output = pd.storeSubject(name);
		pw.println(output);
		rd1.include(request, response);
	}

}
