package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.StudentService;

/**
 * Servlet implementation class StudentShowAll
 */

public class StudentShowAll extends HttpServlet {
	
	StudentService pd = new StudentService();
	
	public StudentShowAll() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		RequestDispatcher rd1 = request.getRequestDispatcher("students.html");
		response.setContentType("text/html");
		
		List<String> output = pd.findStudentAllStudent();
		Iterator<String> li = output.iterator();
		
		pw.println("<table>\n" + 
				"  <tr>\n" + 
				"    <th>Student Name</th>\n" + 
				"    <th>Class</th>\n" + 
				"  </tr>");
		while (li.hasNext()) {
			String student = li.next(); 
			pw.println("<tr><td>" + student + "</td>");
			String className = li.next(); // it's certain there's a pair of records
			pw.println("<td>" + className + "</td></tr>");
		}
		pw.println("</table>");
		
		rd1.include(request, response);
		
	}

}
