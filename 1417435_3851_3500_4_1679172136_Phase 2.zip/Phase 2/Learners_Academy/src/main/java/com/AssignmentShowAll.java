package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.AssignmentService;

/**
 * Servlet implementation class AssignmentShowAll
 */

public class AssignmentShowAll extends HttpServlet {
	
	AssignmentService pd = new AssignmentService();
	
	public AssignmentShowAll() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		RequestDispatcher rd1 = request.getRequestDispatcher("assignments.html");
		response.setContentType("text/html");
		
		List<String> output = pd.findAssignmentAllAssignment();
		Iterator<String> li = output.iterator();
		
		pw.println("<table>\n" + 
				"  <tr>\n" + 
				"    <th>Class</th>\n" + 
				"    <th>Subject</th>\n" +
				"    <th>Teacher</th>\n" +
				"  </tr>");
		while (li.hasNext()) {
			String className = li.next(); // it's certain there's a triplet of records
			pw.println("<tr><td>" + className + "</td>");
			String subject = li.next(); 
			pw.println("<td>" + subject + "</td>");
			String teacher = li.next(); 
			pw.println("<td>" + teacher + "</td></tr>");
		}
		pw.println("</table>");
		
		rd1.include(request, response);
		
	}

}
