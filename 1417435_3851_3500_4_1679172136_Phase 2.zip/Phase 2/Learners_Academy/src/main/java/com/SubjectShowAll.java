package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.Subject;
import com.service.SubjectService;

/**
 * Servlet implementation class SubjectShowAll
 */

public class SubjectShowAll extends HttpServlet {
	
	SubjectService pd = new SubjectService();
	
	public SubjectShowAll() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		RequestDispatcher rd1 = request.getRequestDispatcher("subjects.html");
		response.setContentType("text/html");
		
		List<String> output = pd.findSubjectAllSubject();
		Iterator<String> li = output.iterator();
		while (li.hasNext()) {
			String subject = li.next(); 
			pw.println("<h3>" + subject + "</h3>");
		}
		
		rd1.include(request, response);
		
	}

}
